# Approve Demo

Šis puslapis leidžia testuoti tokenų approve funkciją naudojant ethers.js ir MetaMask.